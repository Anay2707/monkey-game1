
var monkey , monkey_running,monkeyI
var bananaF ,bananaImage, obstacle, obstacleImage,bananasGroup;
var FoodGroup, obstaclesGroup
var survivalTime;
var PLAY = 1;
var END = 0;
var gameState = PLAY; 
var ground;

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(600,400); 
  
  monkey = createSprite (50,350,20,20);
 
  monkey.addAnimation("running",monkey_running)
  monkey.scale = 0.1
  
  survivalTime = 0;
  
  ground = createSprite(300,380,900,20);
  ground.velocityX = -4;
  
  obstaclesGroup = new Group();
  bananasGroup = new Group();
  
}


function draw() {
  
  background(255);
  if (gameState === PLAY) {
    if(keyDown("space")&& monkey.y >= 339) {
        monkey.velocityY = -12;
    }
    monkey.velocityY = monkey.velocityY + 0.8;
    
    banana();
    
    spawnObstacles();
    
   survivalTime = survivalTime +
    Math.round(getFrameRate()/60);
    stroke("black");
    textSize(20);
    fill("black");
    text("Survival Time :"+ survivalTime,100,50);
    
    if (ground.x = -1){
      ground.x = ground.width/2;
    }
    
     if(monkey.isTouching(obstaclesGroup)){
       gameState = END;
     }
    
  }
  
  if (gameState === END) {
    obstaclesGroup.setLifetimeEach(-1);
    bananasGroup.setLifetimeEach(-1);
     
     obstaclesGroup.setVelocityXEach(0);
     bananasGroup.setVelocityXEach(0);
    if (keydown(space)) {
      reset();
    }
  }   
    
 
  
  monkey.collide(ground);

  
 drawSprites();
}

function banana() {
  
  if (frameCount % 80 === 0) {
    bananaF = createSprite(600,365,10,40); 
    bananaF.y = Math.round(random(120,200));
    bananaF.addImage(bananaImage);
    bananaF.velocityX = -3;
    bananaF.lifetime = 200;
    bananaF.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
    bananaF.scale = 0.1;
    
    bananasGroup.add(bananaF);
}
}

function spawnObstacles() {
  if (frameCount % 300 === 0){
   var obstacle = createSprite(600,165,10,40);
   obstacle.velocityX = -(6 + score/100);
       
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.5;
    obstacle.lifetime = 300;
   
   //add each obstacle to the group
    obstaclesGroup.add(obstacle);
    obstaclesGroup.addImage(obstacleImage);
 }
  
}

function reset() {
  survivalTime = 0;
  
  obstaclesGroup.destroyEach(); 
   
  bananasGroup.destroyEach();
  
  text("press r to restart");
  
  if (keyDown(r)){
    gameState = PLAY;
  } 
}
